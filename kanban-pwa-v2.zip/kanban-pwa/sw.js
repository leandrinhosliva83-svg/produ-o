const CACHE = 'kanban-v1';
const FILES = ['/', '/index.html', '/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(clients.claim());
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});

// Recebe mensagem do app para agendar notificação
self.addEventListener('message', e => {
  if (e.data && e.data.type === 'SCHEDULE_ALARM') {
    const { taskId, taskText, alarmTime } = e.data;
    const delay = new Date(alarmTime) - Date.now();
    if (delay <= 0) return;

    setTimeout(() => {
      self.registration.showNotification('⏰ Lembrete de Pendência', {
        body: taskText,
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        tag: 'alarm-' + taskId,
        requireInteraction: true,
        vibrate: [300, 100, 300, 100, 300],
        actions: [
          { action: 'dismiss', title: 'Dispensar' },
          { action: 'done', title: 'Concluir tarefa' }
        ],
        data: { taskId }
      });
    }, delay);
  }

  if (e.data && e.data.type === 'CANCEL_ALARM') {
    // Não há API para cancelar setTimeout no SW, mas a notificação não aparece se tarefa deletada
  }
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  if (e.action === 'done') {
    e.waitUntil(
      clients.matchAll({ type: 'window' }).then(cs => {
        const taskId = e.notification.data && e.notification.data.taskId;
        if (cs.length > 0) {
          cs[0].postMessage({ type: 'MARK_DONE', taskId });
          cs[0].focus();
        } else {
          clients.openWindow('/');
        }
      })
    );
  } else {
    e.waitUntil(
      clients.matchAll({ type: 'window' }).then(cs => {
        if (cs.length > 0) cs[0].focus();
        else clients.openWindow('/');
      })
    );
  }
});
