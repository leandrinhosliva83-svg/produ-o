# ⚡ Pendências — Kanban com Alarmes

App PWA que funciona instalado no Android com notificações mesmo com o app fechado.

---

## 📲 Como publicar no GitHub Pages (passo a passo)

### 1. Criar repositório no GitHub
1. Acesse https://github.com/new
2. Nome: `pendencias` (ou qualquer nome)
3. Marque **Public**
4. Clique em **Create repository**

### 2. Fazer upload dos arquivos
1. Na página do repositório criado, clique em **uploading an existing file**
2. Arraste todos esses arquivos de uma vez:
   - `index.html`
   - `sw.js`
   - `manifest.json`
   - `icon-192.png`
   - `icon-512.png`
3. Clique em **Commit changes**

### 3. Ativar GitHub Pages
1. Vá em **Settings** (engrenagem no menu do repositório)
2. No menu lateral, clique em **Pages**
3. Em "Source", selecione **main** e pasta **/ (root)**
4. Clique em **Save**
5. Aguarde ~1 minuto e seu link aparecerá:
   `https://SEU_USUARIO.github.io/pendencias`

### 4. Instalar no Android
1. Abra o link no **Chrome** do Android
2. Chrome vai mostrar um banner "Adicionar à tela inicial" — toque nele
3. Ou vá no menu (3 pontos) → "Adicionar à tela inicial"
4. Permita as **notificações** quando o app pedir
5. Pronto! Agora aparece como app na sua tela

---

## ⏰ Como funcionam os alarmes

- Defina um alarme em qualquer tarefa tocando em ⏰
- O **Service Worker** (sw.js) fica rodando em segundo plano no Android
- Na hora certa, aparece uma notificação no topo da tela — mesmo com o app fechado
- Toque na notificação para abrir o app, ou "Concluir tarefa" direto da notificação

---

## 📁 Arquivos do projeto

| Arquivo | O que faz |
|---|---|
| `index.html` | App principal — todo o visual e lógica |
| `sw.js` | Service Worker — roda em segundo plano e dispara notificações |
| `manifest.json` | Define nome, ícone e cores do app instalado |
| `icon-192.png` | Ícone do app (tela inicial) |
| `icon-512.png` | Ícone do app (splash screen) |
