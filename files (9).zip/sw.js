// Service Worker — Grupo Moreno Frota
var CACHE = 'frota-v1';

self.addEventListener('install', function(e) {
  self.skipWaiting();
});

self.addEventListener('activate', function(e) {
  e.waitUntil(clients.claim());
});

self.addEventListener('push', function(e) {
  var data = {};
  try { data = e.data.json(); } catch(err) { data = { title: '🚨 Alerta de Meta', body: e.data ? e.data.text() : 'Proprietário abaixo da meta!' }; }
  e.waitUntil(
    self.registration.showNotification(data.title || '🚨 Alerta de Meta — Grupo Moreno', {
      body: data.body || 'Proprietário abaixo da meta!',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      vibrate: [400, 100, 400, 100, 800],
      requireInteraction: true,
      tag: 'alerta-meta',
      renotify: true,
      silent: false,
      actions: [{ action: 'abrir', title: '📊 Ver Dashboard' }]
    })
  );
});

self.addEventListener('message', function(e) {
  if (!e.data || e.data.type !== 'NOTIF') return;
  var alertas = e.data.alertas || [];
  if (!alertas.length) return;
  var body = alertas.map(function(a) {
    return '⚠️ ' + a.emp + ' | ' + a.nome + ' — ' + a.pct + '% (' + a.proj + 't / ' + a.meta + 't)';
  }).join('\n');
  self.registration.showNotification('🚨 ALERTA DE META — Grupo Moreno', {
    body: body,
    vibrate: [400, 100, 400, 100, 800],
    requireInteraction: true,
    tag: 'alerta-meta',
    renotify: true,
    silent: false
  });
});

self.addEventListener('notificationclick', function(e) {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: 'window' }).then(function(cs) {
    if (cs.length) { cs[0].focus(); return; }
    clients.openWindow('/');
  }));
});
